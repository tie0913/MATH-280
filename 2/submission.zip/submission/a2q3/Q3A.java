package a2q3;

public class Q3A extends A2Q3ACFunction{

    @Override
    public double calculate(double x) {
        return 0.25 * x;
    }

}
