package a2q3;

public class Q3C extends A2Q3ACFunction{

    @Override
    public double calculate(double x) {
        return Math.sqrt(4 - Math.pow(x, 2));
    }

}
