package a2q3;

public class Q3B extends A2Q3ACFunction{

    @Override
    public double calculate(double x) {
    
        return -1 * (x + 2) * (x - 8) / 5;
    }

}
